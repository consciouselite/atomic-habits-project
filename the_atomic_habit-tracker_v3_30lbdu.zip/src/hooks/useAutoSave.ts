import { useState, useEffect, useCallback } from 'react';
import { debounce } from '../utils/debounce';
import toast from 'react-hot-toast';

interface AutoSaveOptions<T> {
  data: T;
  onSave: (data: T) => Promise<void>;
  debounceMs?: number;
}

export function useAutoSave<T>({ data, onSave, debounceMs = 1000 }: AutoSaveOptions<T>) {
  const [saving, setSaving] = useState(false);
  const [lastSavedData, setLastSavedData] = useState(data);

  const debouncedSave = useCallback(
    debounce(async (newData: T) => {
      try {
        setSaving(true);
        await onSave(newData);
        setLastSavedData(newData);
        toast.success('Changes saved');
      } catch (error) {
        toast.error('Failed to save changes');
        console.error('Auto-save error:', error);
      } finally {
        setSaving(false);
      }
    }, debounceMs),
    [onSave]
  );

  useEffect(() => {
    if (JSON.stringify(data) !== JSON.stringify(lastSavedData)) {
      debouncedSave(data);
    }
  }, [data, lastSavedData, debouncedSave]);

  return { saving };
}
