import { Habit } from '../types';

export const initialHabits: Habit[] = [
  {
    id: '1',
    name: 'Morning Meditation 🧘‍♀️',
    streak: 5,
    completed: false,
    category: 'wellness',
    timeOfDay: 'morning'
  },
  {
    id: '2',
    name: 'Read 30 Minutes 📚',
    streak: 3,
    completed: false,
    category: 'personal',
    timeOfDay: 'evening'
  },
  {
    id: '3',
    name: 'Workout 💪',
    streak: 2,
    completed: false,
    category: 'wellness',
    timeOfDay: 'morning'
  }
];

export const motivationalMessages = [
  "Ready to build your future? Let's crush today's habits! 💪",
  "Small steps today, big results tomorrow. You've got this! ✨",
  "Your 2025 vision is getting closer with every habit completed! 🎯",
  "Remember your 'why' - it's what makes you unstoppable! 🚀"
];

export const onboardingSteps = [
  {
    id: 1,
    title: "What's Your Name?",
    question: "Let's start with your full name",
    placeholder: "Enter your full name",
    fieldName: "name",
    type: "text"
  },
  {
    id: 2,
    title: "Tell Us About Yourself",
    question: "Select how you identify",
    placeholder: "",
    fieldName: "sex",
    type: "sex-select",
    images: [
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100&h=100",
      "https://images.unsplash.com/photo-1580489944761-15a19d67492d?auto=format&fit=crop&q=80&w=100&h=100"
    ]
  },
  {
    id: 3,
    title: "Your Future Self",
    question: "When's your birthday in 2025?",
    placeholder: "Select your birthday",
    fieldName: "birthday",
    type: "date"
  },
  {
    id: 4,
    title: "Your 2025 Vision",
    question: "Imagine it's 2025. What does your ideal life look like?",
    placeholder: "Describe your vision for career, health, and relationships...",
    fieldName: "vision2025",
    type: "textarea"
  },
  {
    id: 5,
    title: "Your Motivation",
    question: "What's your biggest motivation for making these changes?",
    placeholder: "What drives you to become better?",
    fieldName: "motivation",
    type: "textarea"
  },
  {
    id: 6,
    title: "Wellness Goals",
    question: "What specific health and wellness goals do you want to achieve?",
    placeholder: "Exercise routine, nutrition, mental health practices...",
    fieldName: "wellnessGoal",
    type: "textarea"
  },
  {
    id: 7,
    title: "Career Aspirations",
    question: "What career milestones do you want to reach?",
    placeholder: "Skills to learn, positions to achieve, projects to complete...",
    fieldName: "careerGoal",
    type: "textarea"
  },
  {
    id: 8,
    title: "Relationship Goals",
    question: "How do you want to improve your relationships?",
    placeholder: "Family time, social connections, networking...",
    fieldName: "relationshipsGoal",
    type: "textarea"
  },
  {
    id: 9,
    title: "Current Obstacles",
    question: "What's currently holding you back?",
    placeholder: "List your main challenges...",
    fieldName: "obstacles",
    type: "textarea"
  }
];
