import { supabase } from '../lib/supabase';

export const storageApi = {
  uploadImage: async (file: File, path: string) => {
    const { data, error } = await supabase.storage
      .from('progress-images')
      .upload(path, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (error) throw error;
    return data;
  },

  deleteImage: async (path: string) => {
    const { error } = await supabase.storage
      .from('progress-images')
      .remove([path]);

    if (error) throw error;
  },

  getPublicUrl: (path: string) => {
    const { data: { publicUrl } } = supabase.storage
      .from('progress-images')
      .getPublicUrl(path);
    
    return publicUrl;
  }
};
