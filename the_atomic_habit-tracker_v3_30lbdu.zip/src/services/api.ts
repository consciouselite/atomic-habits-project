import { supabase } from '../lib/supabase';
import { Habit, HabitLog, Category } from '../types';

// Habits API
export const habitsApi = {
  getAll: async () => {
    const { data, error } = await supabase
      .from('habits')
      .select(`
        *,
        habit_categories (
          categories (*)
        ),
        habit_logs (*)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },

  create: async (habit: Omit<Habit, 'id'>) => {
    const { data, error } = await supabase
      .from('habits')
      .insert(habit)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  update: async (id: string, updates: Partial<Habit>) => {
    const { data, error } = await supabase
      .from('habits')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  delete: async (id: string) => {
    const { error } = await supabase
      .from('habits')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  getLogs: async (habitId: string) => {
    const { data, error } = await supabase
      .from('habit_logs')
      .select('*')
      .eq('habit_id', habitId)
      .order('completion_date', { ascending: false });

    if (error) throw error;
    return data;
  }
};

// Categories API
export const categoriesApi = {
  getAll: async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');

    if (error) throw error;
    return data;
  },

  create: async (category: Omit<Category, 'id'>) => {
    const { data, error } = await supabase
      .from('categories')
      .insert(category)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  update: async (id: string, updates: Partial<Category>) => {
    const { data, error } = await supabase
      .from('categories')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  delete: async (id: string) => {
    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};

// Habit Logs API
export const habitLogsApi = {
  create: async (log: Omit<HabitLog, 'id'>) => {
    const { data, error } = await supabase
      .from('habit_logs')
      .insert(log)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  delete: async (id: string) => {
    const { error } = await supabase
      .from('habit_logs')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};
