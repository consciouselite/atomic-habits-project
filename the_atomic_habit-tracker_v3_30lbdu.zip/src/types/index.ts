export interface Habit {
  id: string;
  name: string;
  streak: number;
  completed: boolean;
  category: 'wellness' | 'career' | 'relationships' | 'personal';
  timeOfDay?: 'morning' | 'afternoon' | 'evening';
  notes?: string;
  background_color?: string;
  before_image?: string;
  after_image?: string;
}

export interface UserProfile {
  name: string;
  nickname: string;
  sex: 'male' | 'female' | 'other';
  birthday: string;
  vision2025: string;
  motivation: string;
  obstacles: string;
  wellnessGoal: string;
  careerGoal: string;
  relationshipsGoal: string;
}

export interface OnboardingStep {
  id: number;
  title: string;
  question: string;
  placeholder: string;
  fieldName: keyof UserProfile;
  icon?: string;
  type?: 'text' | 'sex-select' | 'date' | 'textarea';
}
