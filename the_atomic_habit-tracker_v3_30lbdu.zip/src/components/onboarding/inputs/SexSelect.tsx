import React from 'react';

interface SexSelectProps {
  value: 'male' | 'female' | 'other';
  onChange: (value: string) => void;
  images?: string[];
}

export default function SexSelect({ value, onChange, images }: SexSelectProps) {
  const options = [
    { value: 'male', label: 'Male', image: images?.[0] || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100&h=100' },
    { value: 'female', label: 'Female', image: images?.[1] || 'https://images.unsplash.com/photo-1580489944761-15a19d67492d?auto=format&fit=crop&q=80&w=100&h=100' }
  ];

  return (
    <div className="grid grid-cols-2 gap-4">
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value)}
          className={`p-4 rounded-lg border-2 transition-all ${
            value === option.value
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-200 hover:border-blue-200'
          }`}
        >
          <img src={option.image} alt={option.label} className="w-full h-24 object-cover rounded-md mb-2" />
          <div className="font-medium text-gray-700 text-center">{option.label}</div>
        </button>
      ))}
    </div>
  );
}
