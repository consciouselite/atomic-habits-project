import React, { useState } from 'react';
import { UserProfile } from '../../types';
import { onboardingSteps } from '../../data/initial-data';
import { ArrowRight } from 'lucide-react';
import OnboardingStep from './OnboardingStep';
import ProgressIndicator from './ProgressIndicator';

interface OnboardingFlowProps {
  onComplete: (profile: UserProfile) => void;
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    nickname: '',
    sex: 'other',
    birthday: '',
    vision2025: '',
    motivation: '',
    obstacles: '',
    wellnessGoal: '',
    careerGoal: '',
    relationshipsGoal: ''
  });

  const handleNext = () => {
    if (currentStep === onboardingSteps.length - 1) {
      localStorage.setItem('userProfile', JSON.stringify(profile));
      onComplete(profile);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleInputChange = (value: string) => {
    const currentField = onboardingSteps[currentStep].fieldName;
    setProfile(prev => ({ ...prev, [currentField]: value }));
  };

  const currentStepData = onboardingSteps[currentStep];
  const isNextDisabled = !profile[currentStepData.fieldName];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-white rounded-2xl shadow-xl p-8">
        <ProgressIndicator
          totalSteps={onboardingSteps.length}
          currentStep={currentStep}
        />

        <div className="mb-4 text-center">
          <span className="text-4xl mb-2">{currentStepData.icon}</span>
        </div>

        <OnboardingStep
          step={currentStepData}
          value={profile[currentStepData.fieldName]}
          onChange={handleInputChange}
        />

        <button
          onClick={handleNext}
          disabled={isNextDisabled}
          className={`w-full mt-6 py-3 px-6 rounded-lg font-semibold flex items-center justify-center transition-colors ${
            isNextDisabled
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {currentStep === onboardingSteps.length - 1 ? 'Get Started' : 'Continue'}
          <ArrowRight className="ml-2 h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
