import React from 'react';
import { OnboardingStep as StepType } from '../../types';
import SexSelect from './inputs/SexSelect';

interface OnboardingStepProps {
  step: StepType;
  value: string;
  onChange: (value: string) => void;
}

export default function OnboardingStep({ step, value, onChange }: OnboardingStepProps) {
  const renderInput = () => {
    switch (step.type) {
      case 'sex-select':
        return <SexSelect value={value as 'male' | 'female' | 'other'} onChange={onChange} images={step.images} />;
      case 'date':
        return (
          <input
            type="date"
            min="2025-01-01"
            max="2025-12-31"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        );
      case 'text':
        return (
          <input
            type="text"
            placeholder={step.placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        );
      default:
        return (
          <textarea
            className="w-full p-4 border border-gray-200 rounded-lg h-32 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder={step.placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
          />
        );
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-3xl font-bold text-gray-800">{step.title}</h2>
      <p className="text-gray-600">{step.question}</p>
      {renderInput()}
    </div>
  );
}
