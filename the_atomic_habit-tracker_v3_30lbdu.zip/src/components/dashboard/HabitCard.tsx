import React, { useState } from 'react';
import { Habit } from '../../types';
import { CheckCircle, Circle, Edit2, ChevronDown, ChevronUp } from 'lucide-react';
import HabitForm from '../habits/HabitForm';
import ProgressImages from '../habits/ProgressImages';
import { useAutoSave } from '../../hooks/useAutoSave';
import { habitsApi } from '../../services/api';
import { categoryColors } from '../../utils/categoryColors';

interface HabitCardProps {
  habit: Habit;
  onToggle: (id: string) => void;
}

export default function HabitCard({ habit, onToggle }: HabitCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [localHabit, setLocalHabit] = useState(habit);
  
  const { saving } = useAutoSave({
    data: localHabit,
    onSave: async (data) => {
      await habitsApi.update(data.id, data);
    }
  });

  const handleImageUpdate = async (type: 'before' | 'after', url: string) => {
    const updates = {
      ...localHabit,
      [type === 'before' ? 'before_image' : 'after_image']: url
    };
    setLocalHabit(updates);
    await habitsApi.update(habit.id, updates);
  };

  const backgroundColor = categoryColors[localHabit.category as keyof typeof categoryColors];

  return (
    <div 
      className="bg-white rounded-lg shadow-sm overflow-hidden mb-3 hover:shadow-md transition-shadow"
      style={{ backgroundColor }}
    >
      {/* Title and Status Section */}
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => onToggle(habit.id)}
              className="focus:outline-none"
            >
              {localHabit.completed ? (
                <CheckCircle className="w-6 h-6 text-white" />
              ) : (
                <Circle className="w-6 h-6 text-white" />
              )}
            </button>
            <div>
              <h3 className="font-medium text-white">{localHabit.name}</h3>
              <p className="text-sm text-white opacity-90">
                {localHabit.timeOfDay} • {localHabit.frequency}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-white">
              {localHabit.streak} day{localHabit.streak !== 1 ? 's' : ''}
            </span>
            {localHabit.streak >= 3 && <span className="text-xl">🔥</span>}
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="text-white opacity-80 hover:opacity-100"
            >
              <Edit2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Progress Toggle Button */}
        <button
          onClick={() => setShowProgress(!showProgress)}
          className="mt-2 text-white opacity-80 hover:opacity-100 flex items-center"
        >
          {showProgress ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          <span className="ml-1 text-sm">
            {showProgress ? 'Hide Progress' : 'Show Progress'}
          </span>
        </button>
      </div>

      {/* Progress Images Section */}
      {showProgress && (
        <div className="p-4 bg-white">
          <ProgressImages
            habitId={habit.id}
            beforeImage={localHabit.before_image}
            afterImage={localHabit.after_image}
            onImageUpdate={handleImageUpdate}
          />
        </div>
      )}

      {/* Edit Modal */}
      <HabitForm
        habit={localHabit}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={async (updates) => {
          const updatedHabit = { ...localHabit, ...updates };
          setLocalHabit(updatedHabit as Habit);
          await habitsApi.update(habit.id, updates);
        }}
        onDelete={async (id) => {
          await habitsApi.delete(id);
        }}
      />

      {/* Saving Indicator */}
      {saving && (
        <div className="absolute top-2 right-2">
          <span className="text-sm text-white opacity-80">Saving...</span>
        </div>
      )}
    </div>
  );
}
