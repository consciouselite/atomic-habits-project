import React, { useState } from 'react';
import { Habit } from '../../types';
import { initialHabits, motivationalMessages } from '../../data/initial-data';
import HabitCard from './HabitCard';
import CoachTweet from './CoachTweet';
import { Plus, TrendingUp } from 'lucide-react';
import AddHabitModal from './AddHabitModal';

export default function Dashboard() {
  const [habits, setHabits] = useState<Habit[]>(initialHabits);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const toggleHabit = (id: string) => {
    setHabits(habits.map(habit =>
      habit.id === id ? { ...habit, completed: !habit.completed } : habit
    ));
  };

  const addHabit = (habit: Omit<Habit, 'id' | 'streak' | 'completed'>) => {
    const newHabit: Habit = {
      ...habit,
      id: Date.now().toString(),
      streak: 0,
      completed: false
    };
    setHabits([...habits, newHabit]);
    setIsModalOpen(false);
  };

  const motivationalMessage = motivationalMessages[
    Math.floor(Math.random() * motivationalMessages.length)
  ];

  // Calculate days since start (for demo purposes, using a static number)
  const currentDay = 7; // This would normally be calculated from the start date

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto p-4">
        <CoachTweet message={motivationalMessage} day={currentDay} />

        <div className="flex justify-between items-center my-6">
          <h2 className="text-xl font-semibold text-gray-800">Today's Habits</h2>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center space-x-2 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>Add Habit</span>
          </button>
        </div>

        <div className="space-y-4">
          {habits.map(habit => (
            <HabitCard
              key={habit.id}
              habit={habit}
              onToggle={toggleHabit}
            />
          ))}
        </div>

        <div className="mt-8 bg-white rounded-lg p-6 shadow-sm">
          <div className="flex items-center space-x-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-800">Quick Stats</h2>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Current Streaks</p>
              <p className="text-2xl font-bold text-gray-800">
                {habits.reduce((acc, habit) => acc + habit.streak, 0)}
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Completion Rate</p>
              <p className="text-2xl font-bold text-gray-800">
                {Math.round((habits.filter(h => h.completed).length / habits.length) * 100)}%
              </p>
            </div>
          </div>
        </div>
      </div>

      <AddHabitModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={addHabit}
      />
    </div>
  );
}
