import React from 'react';
import { Calendar } from 'lucide-react';

interface CoachTweetProps {
  message: string;
  day: number;
}

export default function CoachTweet({ message, day }: CoachTweetProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start space-x-3">
        <img
          src="https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=150&h=150"
          alt="Coach Alex"
          className="w-12 h-12 rounded-full object-cover border-2 border-blue-100"
        />
        
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-gray-900">Coach Alex</h3>
              <p className="text-sm text-gray-500">@atomiccoach</p>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="w-4 h-4 mr-1" />
              <span>Day {day}/365</span>
            </div>
          </div>
          
          <p className="mt-2 text-gray-800">{message}</p>
          
          <div className="mt-3 flex items-center space-x-4 text-gray-500 text-sm">
            <span className="flex items-center">
              <span className="mr-1">🎯</span>
              Focus
            </span>
            <span className="flex items-center">
              <span className="mr-1">💪</span>
              Consistency
            </span>
            <span className="flex items-center">
              <span className="mr-1">🚀</span>
              Growth
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
