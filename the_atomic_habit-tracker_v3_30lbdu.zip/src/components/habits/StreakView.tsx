import React, { useState } from 'react';
import { Calendar, TrendingUp } from 'lucide-react';
import { format, getDaysInMonth, startOfMonth, eachDayOfInterval, isSameMonth, isSameYear } from 'date-fns';

interface StreakViewProps {
  streaks: {
    date: string;
    completed: boolean;
  }[];
  view: 'monthly' | 'yearly';
  onViewChange: (view: 'monthly' | 'yearly') => void;
}

export default function StreakView({ streaks, view, onViewChange }: StreakViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const handlePrevMonth = () => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const getDays = () => {
    if (view === 'monthly') {
      const daysInMonth = getDaysInMonth(currentDate);
      const firstDayOfMonth = startOfMonth(currentDate);
      return eachDayOfInterval({
        start: firstDayOfMonth,
        end: new Date(currentDate.getFullYear(), currentDate.getMonth(), daysInMonth)
      }).map(date => {
        const dateString = format(date, 'yyyy-MM-dd');
        return {
          date: dateString,
          completed: streaks.some(streak => streak.date === dateString)
        };
      });
    } else {
      const startOfYear = new Date(currentDate.getFullYear(), 0, 1);
      const endOfYear = new Date(currentDate.getFullYear(), 11, 31);
      return eachDayOfInterval({ start: startOfYear, end: endOfYear }).map(date => {
        const dateString = format(date, 'yyyy-MM-dd');
        return {
          date: dateString,
          completed: streaks.some(streak => streak.date === dateString)
        };
      });
    }
  };

  const days = getDays();

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-semibold">Streak History</h2>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => onViewChange('monthly')}
            className={`px-3 py-1 rounded ${
              view === 'monthly'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => onViewChange('yearly')}
            className={`px-3 py-1 rounded ${
              view === 'yearly'
                ? 'bg-blue-100 text-blue-600'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Yearly
          </button>
        </div>
      </div>

      {view === 'monthly' && (
        <div className="flex justify-between items-center mb-4">
          <button onClick={handlePrevMonth} className="text-gray-600 hover:text-gray-800">
            &lt;
          </button>
          <h3 className="text-lg font-medium">
            {format(currentDate, 'MMMM yyyy')}
          </h3>
          <button onClick={handleNextMonth} className="text-gray-600 hover:text-gray-800">
            &gt;
          </button>
        </div>
      )}

      <div className="grid grid-cols-7 gap-1">
        {days.map((day, index) => (
          <div
            key={index}
            className={`aspect-square rounded ${
              day.completed
                ? 'bg-green-100 border border-green-200'
                : 'bg-gray-50 border border-gray-100'
            }`}
            title={day.date}
          />
        ))}
      </div>
    </div>
  );
}
