import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface ProgressImagesProps {
  habitId: string;
  beforeImage?: string;
  afterImage?: string;
  onImageUpdate: (type: 'before' | 'after', url: string) => Promise<void>;
}

export default function ProgressImages({ habitId, beforeImage, afterImage, onImageUpdate }: ProgressImagesProps) {
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async (type: 'before' | 'after', file: File) => {
    try {
      setUploading(true);

      // Validate file type
      if (!file.type.startsWith('image/')) {
        throw new Error('Please upload an image file');
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('Image size should be less than 5MB');
      }

      // Upload to Supabase Storage
      const fileName = `${habitId}/${type}-${Date.now()}`;
      const { data, error } = await supabase.storage
        .from('progress-images')
        .upload(fileName, file);

      if (error) throw error;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('progress-images')
        .getPublicUrl(fileName);

      await onImageUpdate(type, publicUrl);
      toast.success('Image uploaded successfully');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mt-4 grid grid-cols-2 gap-4">
      <div className="space-y-2">
        <h3 className="font-medium text-gray-700">Before</h3>
        <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
          {beforeImage ? (
            <img
              src={beforeImage}
              alt="Before progress"
              className="w-full h-full object-cover"
            />
          ) : (
            <label className="flex items-center justify-center w-full h-full cursor-pointer hover:bg-gray-200">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleImageUpload('before', e.target.files[0])}
                disabled={uploading}
              />
              <Upload className="w-6 h-6 text-gray-400" />
            </label>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-medium text-gray-700">After</h3>
        <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
          {afterImage ? (
            <img
              src={afterImage}
              alt="After progress"
              className="w-full h-full object-cover"
            />
          ) : (
            <label className="flex items-center justify-center w-full h-full cursor-pointer hover:bg-gray-200">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleImageUpload('after', e.target.files[0])}
                disabled={uploading}
              />
              <Upload className="w-6 h-6 text-gray-400" />
            </label>
          )}
        </div>
      </div>
    </div>
  );
}
