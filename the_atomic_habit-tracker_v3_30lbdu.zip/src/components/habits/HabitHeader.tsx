import React from 'react';
import { Habit } from '../../types';
import { Star } from 'lucide-react';

interface HabitHeaderProps {
  habit: Habit;
  onColorChange: (color: string) => void;
}

export default function HabitHeader({ habit, onColorChange }: HabitHeaderProps) {
  return (
    <div 
      className="p-4 rounded-t-lg flex items-center justify-between"
      style={{ backgroundColor: habit.background_color || '#ffffff' }}
    >
      <div className="flex items-center space-x-2">
        <h2 className="text-xl font-bold text-gray-800">{habit.title}</h2>
        {habit.streak >= 7 && <Star className="w-5 h-5 text-yellow-400" />}
      </div>
      
      <input
        type="color"
        value={habit.background_color || '#ffffff'}
        onChange={(e) => onColorChange(e.target.value)}
        className="w-8 h-8 rounded cursor-pointer"
        title="Change background color"
      />
    </div>
  );
}
