export const categoryColors = {
  wellness: '#4ade80', // Green
  career: '#60a5fa', // Blue
  relationships: '#f472b6', // Pink
  personal: '#a78bfa' // Purple
};
