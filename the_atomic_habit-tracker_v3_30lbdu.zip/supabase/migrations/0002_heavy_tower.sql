/*
  # Update Users Schema with Contact Information

  1. Changes
    - Add first_name column to users table
    - Add last_name column to users table
    - Add phone column to users table

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE users
ADD COLUMN first_name text,
ADD COLUMN last_name text,
ADD COLUMN phone text;
