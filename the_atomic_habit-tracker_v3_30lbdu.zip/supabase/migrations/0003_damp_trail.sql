/*
  # Add Habit Customization and Progress Features

  1. Changes
    - Add background_color column to habits table
    - Create progress_images table for before/after tracking
    - Add indexes for performance

  2. Security
    - Enable RLS on new table
    - Add policies for image access
*/

-- Add background color to habits
ALTER TABLE habits
ADD COLUMN background_color text;

-- Create progress images table
CREATE TABLE progress_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  image_type text NOT NULL CHECK (image_type IN ('before', 'after')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE progress_images ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own progress images" ON progress_images
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE habits.id = progress_images.habit_id
      AND habits.user_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX progress_images_habit_id_idx ON progress_images(habit_id);
